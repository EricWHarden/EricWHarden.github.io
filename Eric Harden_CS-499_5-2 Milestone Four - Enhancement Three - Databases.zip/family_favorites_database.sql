DROP DATABASE IF EXISTS `sql_family_favorites`;
CREATE DATABASE `sql_family_favorites`; 
USE `sql_family_favorites`;

SET NAMES utf8 ;
SET character_set_client = utf8mb4 ;

CREATE TABLE `family_members` (
  `family_member_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `birth_date` date DEFAULT NULL,
  PRIMARY KEY (`family_member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
INSERT INTO `family_members` VALUES (1,'Eric', 'Harden', '1992-09-30');
INSERT INTO `family_members` VALUES (2,'Joie', 'King', '1991-10-17');
INSERT INTO `family_members` VALUES (3,'Jaiden', 'Jackson', '2010-09-08');
INSERT INTO `family_members` VALUES (4,'Selah', 'Jackson', '2012-12-28');


CREATE TABLE `favorite_movies` (
  `movie_id` int(11) NOT NULL AUTO_INCREMENT,
  `family_member_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `release_date` date DEFAULT NULL,
  `age_rating` varchar(50) NOT NULL,
  `metacritic_score` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`movie_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
INSERT INTO `favorite_movies` VALUES (1,'1', 'Alien', '1979-06-22', 'R', '89');
INSERT INTO `favorite_movies` VALUES (2,'1', 'The Thing', '1982-06-25', 'R', '57');
INSERT INTO `favorite_movies` VALUES (3,'1', 'There Will Be Blood', '2007-12-26', 'R', '93');
INSERT INTO `favorite_movies` VALUES (4,'1', '2001: A Space Odyssey', '1968-04-02', 'G', '84');
INSERT INTO `favorite_movies` VALUES (5,'2', 'Monster-in-Law', '2005-05-13', 'PG-13', '31');
INSERT INTO `favorite_movies` VALUES (6,'2', 'The Notebook', '2004-06-25', 'PG-13', '53');
INSERT INTO `favorite_movies` VALUES (7,'2', 'P.S. I Love You', '2007-12-21', 'PG-13', '39');
INSERT INTO `favorite_movies` VALUES (8,'2', 'Ever After', '1998-07-31', 'PG-13', '66');
INSERT INTO `favorite_movies` VALUES (9,'3', 'Venom', '2018-10-05', 'PG-13', '35');
INSERT INTO `favorite_movies` VALUES (10,'3', 'Pacific Rim', '2013-07-12', 'PG-13', '65');
INSERT INTO `favorite_movies` VALUES (11,'3', 'Godzilla (2014)', '2014-05-16', 'PG-13', '62');
INSERT INTO `favorite_movies` VALUES (12,'3', 'Black Panther', '2018-02-16', 'PG-13', '88');
INSERT INTO `favorite_movies` VALUES (13,'4', 'Frozen (2013)', '2013-11-27', 'PG', '75');
INSERT INTO `favorite_movies` VALUES (14,'4', 'The Incredibles', '2004-11-05', 'PG', '90');
INSERT INTO `favorite_movies` VALUES (15,'4', 'Minions', '2015-07-10', 'PG', '56');
INSERT INTO `favorite_movies` VALUES (16,'4', 'Encanto', '2021-11-24', 'PG', '75');


CREATE TABLE `favorite_tv_shows` (
  `tv_show_id` int(11) NOT NULL AUTO_INCREMENT,
  `family_member_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `release_date` date DEFAULT NULL,
  `age_rating` varchar(50) NOT NULL,
  `metacritic_score` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`tv_show_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
INSERT INTO `favorite_tv_shows` VALUES (1,'1', 'The Venture Brothers', '2004-08-07', 'TV-MA', '');
INSERT INTO `favorite_tv_shows` VALUES (2,'1', 'Breaking Bad', '2008-01-20', 'TV-MA', '87');
INSERT INTO `favorite_tv_shows` VALUES (3,'1', 'Mad Men', '2007-07-19', 'TV-MA', '86');
INSERT INTO `favorite_tv_shows` VALUES (4,'1', 'Seinfeld', '1989-07-05', 'TV-PG', '84');
INSERT INTO `favorite_tv_shows` VALUES (5,'2', 'Grey''s Anatomy', '2005-03-27', 'TV-14', '64');
INSERT INTO `favorite_tv_shows` VALUES (6,'2', 'Criminal Minds', '2005-09-22', 'TV-14', '42');
INSERT INTO `favorite_tv_shows` VALUES (7,'2', 'NCIS', '2003-09-23', 'TV-14', '51');
INSERT INTO `favorite_tv_shows` VALUES (8,'2', 'Friends', '1994-09-22', 'TV-PG', '65');
INSERT INTO `favorite_tv_shows` VALUES (9,'3', 'Naruto', '2002-10-03', 'TV-PG', '');
INSERT INTO `favorite_tv_shows` VALUES (10,'3', 'Bunk''d', '2015-07-31', 'TV-G', '65');
INSERT INTO `favorite_tv_shows` VALUES (11,'3', 'The Big Bang Theory', '2007-09-24', 'TV-PG', '61');
INSERT INTO `favorite_tv_shows` VALUES (12,'3', 'The Mandalorian', '2019-11-12', 'TV-14', '71');
INSERT INTO `favorite_tv_shows` VALUES (13,'4', 'Friends', '1994-09-22', 'TV-PG', '65');
INSERT INTO `favorite_tv_shows` VALUES (14,'4', 'The Big Bang Theory', '2007-09-24', 'TV-PG', '61');
INSERT INTO `favorite_tv_shows` VALUES (15,'4', 'Bunk''d', '2015-07-31', 'TV-G', '');
INSERT INTO `favorite_tv_shows` VALUES (16,'4', 'Adventure Time', '2010-04-05', 'TV-PG', '');


CREATE TABLE `favorite_video_games` (
  `video_game_id` int(11) NOT NULL AUTO_INCREMENT,
  `family_member_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `release_date` date DEFAULT NULL,
  `age_rating` varchar(50) NOT NULL,
  `metacritic_score` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`video_game_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
INSERT INTO `favorite_video_games` VALUES (1,'1', 'Bioshock', '2007-08-21', 'M', '96');
INSERT INTO `favorite_video_games` VALUES (2,'1', 'Dead Space', '2008-10-20', 'M', '86');
INSERT INTO `favorite_video_games` VALUES (3,'1', 'The Last of Us', '2013-06-14', 'M', '95');
INSERT INTO `favorite_video_games` VALUES (4,'1', 'Resident Evil 4', '2005-01-11', 'M', '96');
INSERT INTO `favorite_video_games` VALUES (5,'2', 'The Last of Us', '2013-06-14', 'M', '95');
INSERT INTO `favorite_video_games` VALUES (6,'2', 'Call of Duty 4: Modern Warfare', '2007-11-05', 'M', '92');
INSERT INTO `favorite_video_games` VALUES (7,'2', 'Horizon: Zero Dawn', '2017-02-28', 'T', '89');
INSERT INTO `favorite_video_games` VALUES (8,'2', 'God of War (2018)', '2018-04-20', 'M', '94');
INSERT INTO `favorite_video_games` VALUES (9,'3', 'Fortnite', '2017-07-21', 'T', '78');
INSERT INTO `favorite_video_games` VALUES (10,'3', 'Subnautica', '2018-01-23', 'E10+', '87');
INSERT INTO `favorite_video_games` VALUES (11,'3', 'Apex Legends', '2019-02-04', 'T', '88');
INSERT INTO `favorite_video_games` VALUES (12,'3', 'Halo: Combat Evolved', '2001-11-14', 'M', '97');
INSERT INTO `favorite_video_games` VALUES (13,'4', 'Animal Crossing: New Horizons', '2020-03-20', 'E', '90');
INSERT INTO `favorite_video_games` VALUES (14,'4', 'Mario Kart 8 Deluxe', '2017-04-28', 'E', '92');
INSERT INTO `favorite_video_games` VALUES (15,'4', 'Minecraft', '2011-11-18', 'E', '93');
INSERT INTO `favorite_video_games` VALUES (16,'4', 'Chicory: A Colorful Tale', '2021-06-10', 'E', '87');
