package com.example.ericharden_cs_360_5_3projecttwo.provider;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteQueryBuilder;
import android.net.Uri;
import android.text.TextUtils;

import com.example.ericharden_cs_360_5_3projecttwo.MyDBHandler;

//Establishes UserContentProvider class using ContentProvider as a base
public class UserContentProvider extends ContentProvider {
    private static final String AUTHORITY = "com.example.ericharden_cs_360_5_3projecttwo.provider.UserContentProvider";
    private static final String USER_TABLE = "users";
    public static final Uri CONTENT_URI = Uri.parse("content://"+ AUTHORITY +"/"+ USER_TABLE);

    public static final int USER = 4;
    public static final int USERNAME=5;

    private static final UriMatcher sURIMatcher = new UriMatcher(UriMatcher.NO_MATCH);


    static {
        sURIMatcher.addURI(AUTHORITY,USER_TABLE,USER);
        sURIMatcher.addURI(AUTHORITY,USER_TABLE + "/#",USERNAME);
    }

    //Calls MyDBHandler class
    private MyDBHandler myDB;
    public UserContentProvider() {
    }

    //Delete from User Table functionality
    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        int uriType = sURIMatcher.match(uri);
        SQLiteDatabase sqlDB = myDB.getWritableDatabase();
        int rowsDeleted;

        switch (uriType) {
            case USER:
                rowsDeleted = sqlDB.delete(MyDBHandler.TABLE_USER,selection,selectionArgs);
                break;
            case USERNAME:
                String id = uri.getLastPathSegment();
                if(TextUtils.isEmpty(selection)) {
                    rowsDeleted = sqlDB.delete(MyDBHandler.TABLE_USER,MyDBHandler.COLUMN_USERNAME + "=" + id, null);
                } else{
                    rowsDeleted = sqlDB.delete(MyDBHandler.TABLE_USER,MyDBHandler.COLUMN_USERNAME + "=" + id + " and " +
                            selection,selectionArgs);
                }
                break;
            default:
                throw new IllegalArgumentException("Unknown URI: "+ uri);

        }
        getContext().getContentResolver().notifyChange(uri,null);
        return rowsDeleted;
    }

    //Exception thrown for unfinished functionality
    @Override
    public String getType(Uri uri) {
        throw new UnsupportedOperationException("Not yet implemented");
    }

    //Insert into User Table functionality
    @Override
    public Uri insert(Uri uri, ContentValues values) {
        int uriType = sURIMatcher.match(uri);
        SQLiteDatabase sqlDB = myDB.getWritableDatabase();

        long id;
        if (uriType == USER) {
            id = sqlDB.insert(MyDBHandler.TABLE_USER, null, values);
        } else {
            throw new IllegalArgumentException("Unknown URI: " + uri);
        }
        getContext().getContentResolver().notifyChange(uri, null);
        return Uri.parse(USER_TABLE + "/" + id);

    }

    //Return
    @Override
    public boolean onCreate() {
        myDB = new MyDBHandler(getContext(),null, null,1);
        return false;
    }

    //Search User Table functionality
    @Override
    public Cursor query(Uri uri, String[] projection, String selection,
                        String[] selectionArgs, String sortOrder) {
        SQLiteQueryBuilder queryBuilder = new SQLiteQueryBuilder();
        queryBuilder.setTables(MyDBHandler.TABLE_USER);

        int uriType = sURIMatcher.match(uri);

        switch(uriType) {
            case USERNAME:
                queryBuilder.appendWhere(MyDBHandler.COLUMN_ID + "="
                        + uri.getLastPathSegment());
                break;
            case USER:
                break;
            default:
                throw new IllegalArgumentException("Unknown URI");
        }

        Cursor cursor = queryBuilder.query(myDB.getReadableDatabase(),projection,selection, selectionArgs,null,null,sortOrder);
        cursor.setNotificationUri(getContext().getContentResolver(),uri);

        return cursor;
    }

    //Update User Table functionality
    @Override
    public int update(Uri uri, ContentValues values, String selection,
                      String[] selectionArgs) {
        int uriType = sURIMatcher.match(uri);
        SQLiteDatabase sqlDB = myDB.getWritableDatabase();
        int rowsUpdated;

        switch(uriType) {
            case USER:
                rowsUpdated = sqlDB.update(MyDBHandler.TABLE_USER,values,selection,selectionArgs);
                break;
            case USERNAME:
                String id = uri.getLastPathSegment();
                if(TextUtils.isEmpty(selection)){
                    rowsUpdated = sqlDB.update(MyDBHandler.TABLE_USER,values,MyDBHandler.COLUMN_USERNAME + "=" +id,null);
                } else {
                    rowsUpdated = sqlDB.update(MyDBHandler.TABLE_USER, values,MyDBHandler.COLUMN_USERNAME + "="+id + " and " +
                            selection,selectionArgs);
                }
                break;
            default:
                throw new IllegalArgumentException("Unknown URI: "+ uri);

        }
        getContext().getContentResolver().notifyChange(uri,null);
        return rowsUpdated;
    }
}
