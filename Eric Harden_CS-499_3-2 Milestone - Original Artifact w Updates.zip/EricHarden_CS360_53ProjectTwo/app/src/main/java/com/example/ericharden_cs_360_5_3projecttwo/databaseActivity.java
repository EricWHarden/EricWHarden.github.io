package com.example.ericharden_cs_360_5_3projecttwo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.telephony.SmsManager;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import android.os.Bundle;

//Establishes databaseActivity class as an extension of AppCompatActivity
public class databaseActivity extends AppCompatActivity {
    private TableLayout tl;
    private EditText item_code_input,item_name_input,item_price_input;
    private Button  addCategory;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_database);

        tl = findViewById(R.id.tableLayout);
        item_code_input = findViewById(R.id.product_name_input);
        item_name_input = findViewById(R.id.product_description_input);
        item_price_input = findViewById(R.id.item_price_input);

        addCategory = findViewById(R.id.addCategory);
        addCategory.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(databaseActivity.this, ProductActivity.class);
                startActivity(intent);
            }
        });
        populateTable();
    }

    //Add item to table
    public void AddToTable(View view){
        String e_itemcode = item_code_input.getText().toString(),
                e_itemname = item_name_input.getText().toString(),
                e_itemprice = item_price_input.getText().toString();
        if (e_itemcode.isEmpty() || e_itemname.isEmpty() || e_itemprice.isEmpty()){
            Toast.makeText(this, "Please Fill in All the fields", Toast.LENGTH_SHORT).show();
            return;
        }

        //Add to database
        MyDBHandler dbHandler = new MyDBHandler(this, null, null, 1);

        int code = Integer.parseInt(e_itemcode);
        int price = Integer.parseInt(e_itemprice);

        Item item = new Item(code, e_itemname, price);

        dbHandler.addItem(item);
        //Clear input fields
        item_code_input.setText("");
        item_price_input.setText("");
        item_name_input.setText("");
        populateTable();
    }

    //Populate grid view
    public void populateTable(){
        MyDBHandler dbHandler = new MyDBHandler(this, null, null, 1);
        ArrayList<Item> itemList = dbHandler.selectAllItems();
        int count = tl.getChildCount();
        tl.removeViews(1, count-1);
        for (Item item:itemList){
            TableRow tr = new TableRow(this);
            tr.setLayoutParams(new TableRow.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            tr.setBackgroundColor(Color.parseColor("#DAE8FC"));
            tr.setPadding(5, 5, 5,5);

            TextView tx1 = new TextView(this);
            TextView tx2 = new TextView(this);
            TextView tx3 = new TextView(this);

            tx1.setText(String.valueOf(item.getCode()));
            tx2.setText(item.getItemName());
            tx3.setText(String.valueOf(item.getPrice()));

            ImageView img = new ImageView(this);
            img.setImageResource(R.drawable.ic_action_delete);
            img.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v) {
                    if (removeItem(v))
                        deleteRow(v);
                }
            });
            ImageView img1 = new ImageView(this);
            img1.setImageResource(R.drawable.ic_action_edit);
            img1.setOnClickListener(this::lookUpItem);

            tr.addView(tx1);
            tr.addView(tx2);
            tr.addView(tx3);
            tr.addView(img);
            tr.addView(img1);
            tl.addView(tr);
            countItems(item.getItemName());
        }
    }

    //Delete row
    public void deleteRow(View v){
        View row = (View)v.getParent();
        ViewGroup container = ((ViewGroup)row.getParent());
        container.removeView(row);
        container.invalidate();
    }

    //Look up item to form
    public void lookUpItem (View view){
        MyDBHandler dbHandler = new MyDBHandler(this, null, null, 1);
        TableRow row = (TableRow)view.getParent();
        TextView textView = (TextView)row.getChildAt(0);
        Item item = dbHandler.findItem(Integer.parseInt(textView.getText().toString()));

        if (item != null){
            item_code_input.setText(String.valueOf(item.getCode()));
            item_name_input.setText(item.getItemName());
            item_price_input.setText(String.valueOf(item.getPrice()));
        }
        else {
            item_code_input.setText("No Match Found");
        }
    }

    //Remove item from table
    public boolean removeItem (View view){
        MyDBHandler dbHandler = new MyDBHandler(this, null, null, 1);
        TableRow row = (TableRow)view.getParent();
        TextView textView = (TextView)row.getChildAt(0);
        boolean result = dbHandler.deleteItem(Integer.parseInt(textView.getText().toString()));

        if(result) {
            item_code_input.setText("Record Deleted");
            item_name_input.setText("");
            item_price_input.setText("");
        }
        else
            item_code_input.setText("Delete Unsuccessful");

        return result;
    }

    //CountItems with the same name/category
    public String countItems(String productName){
        int count = 0;
        ArrayList<Item> items = new ArrayList<>();
        String items_running_low = "";
        for (Item item: items) {
            count++;
        }
        if (count < 10) {
            items_running_low = productName;
            sendSMS(productName);
        }
        return String.valueOf(count);
    }

    //Send SMS if item quantity is less than 10
    public void sendSMS(String item_name) {
        String phoneNum = "+3038274304"; //txtPhoneNum.getText().toString();
        String message = item_name + "is running low.";

        try {
            SmsManager smgr = SmsManager.getDefault();
            smgr.sendTextMessage(phoneNum, null, message, null, null);
            Toast.makeText(databaseActivity.this, "SMS Sent Successfully", Toast.LENGTH_SHORT).show();
        }
        catch (Exception e){
            Toast.makeText(databaseActivity.this, "SMS Failed to Send, Please Try Again", Toast.LENGTH_SHORT).show();
        }
    }
}