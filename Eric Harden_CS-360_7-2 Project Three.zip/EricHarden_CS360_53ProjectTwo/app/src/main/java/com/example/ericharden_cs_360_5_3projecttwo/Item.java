package com.example.ericharden_cs_360_5_3projecttwo;

public class Item {
    private int _code;
    private String _itemname;
    private int _price;

    public Item(){

    }

    //Constructor
    public Item(int code, String itemname, int price){
        this._code = code;
        this._itemname = itemname;
        this._price = price;
    }

    //Constructor taking two variables: itemname and price

    public Item(String itemname, int price){
        this._itemname = itemname;
        this._price = price;
    }

    //Getter and Setter Methods
    public int getCode() {return _code;}
    public void setCode(int code) {this._code = code;}
    public String getItemName() {return _itemname;}
    public void setItemName(String productname) {this._itemname = productname;}
    public int getPrice() {return _price;}
    public void setPrice(int quantity) {this._price = quantity;}
}
