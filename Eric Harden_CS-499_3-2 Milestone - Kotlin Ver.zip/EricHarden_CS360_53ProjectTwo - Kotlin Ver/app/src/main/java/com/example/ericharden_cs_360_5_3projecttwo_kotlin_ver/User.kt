package com.example.ericharden_cs_360_5_3projecttwo_kotlin_ver

class User {
    //Getter and Setter Methods
    var username: String? = null
    var password: String? = null

    constructor() {}
    constructor(username: String?, password: String?) {
        this.username = username
        this.password = password
    }
}