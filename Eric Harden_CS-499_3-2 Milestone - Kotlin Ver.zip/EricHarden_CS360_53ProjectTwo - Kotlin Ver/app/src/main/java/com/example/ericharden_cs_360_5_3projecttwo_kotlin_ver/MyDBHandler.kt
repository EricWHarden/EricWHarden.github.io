package com.example.ericharden_cs_360_5_3projecttwo_kotlin_ver

import android.content.ContentResolver
import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteDatabase.CursorFactory
import android.database.sqlite.SQLiteOpenHelper
import com.example.ericharden_cs_360_5_3projecttwo_kotlin_ver.provider.ItemContentProvider
import com.example.ericharden_cs_360_5_3projecttwo_kotlin_ver.provider.MyContentProvider
import com.example.ericharden_cs_360_5_3projecttwo_kotlin_ver.provider.UserContentProvider

//Establishes MyDBHandler class as extension of SQLiteOpenHelper
class MyDBHandler(context: Context?, name: String?, factory: CursorFactory?, version: Int) : SQLiteOpenHelper(context, DATABASE_NAME, factory, DATABASE_VERSION) {
    //Declare and Instantiate Final Variables
    private val myCR: ContentResolver

    init {
        myCR = context!!.contentResolver
    }

    //Create All Tables
    override fun onCreate(db: SQLiteDatabase) {
        val createProductsTable = ("CREATE TABLE " +
                TABLE_PRODUCTS + "(" +
                COLUMN_ID + " INTEGER PRIMARY KEY," +
                COLUMN_PRODUCTNAME
                + " TEXT," + COLUMN_DESCRIPTION + " TEXT" + ")")
        val CREATE_ITEMS_TABLE = ("CREATE TABLE " +
                TABLE_ITEMS + "(" +
                COLUMN_CODE + " INTEGER PRIMARY KEY," +
                COLUMN_ITEMNAME
                + " TEXT," + COLUMN_PRICE + " INTEGER" + ")")
        val CREATE_USER_TABLE = ("CREATE TABLE " +
                TABLE_USER + "(" +
                COLUMN_USERNAME + " TEXT PRIMARY KEY," +
                COLUMN_PASSWORD
                + " TEXT" + ")")
        db.execSQL(CREATE_USER_TABLE)
        db.execSQL(createProductsTable)
        db.execSQL(CREATE_ITEMS_TABLE)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_USER")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_PRODUCTS")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_ITEMS")
        onCreate(db)
    }

    //Register and Sign In User
    fun findUser(username: String, password: String): User? {
        val projection = arrayOf(COLUMN_USERNAME, COLUMN_PASSWORD)
        val selection = "username =\"$username\" AND password=\"$password\""
        val cursor = myCR.query(UserContentProvider.CONTENT_URI!!, projection, selection, null, null)
        var user: User? = User()
        println(cursor!!.moveToFirst())
        if (cursor.moveToFirst()) {
            cursor.moveToFirst()
            user!!.username = cursor.getString(0)
            user.password = cursor.getString(1)
            cursor.close()
        } else {
            user = null
        }
        return user
    }

    fun addUser(user: User): Boolean {
        val values = ContentValues()
        values.put(COLUMN_USERNAME, user.username)
        values.put(COLUMN_PASSWORD, user.password)
        myCR.insert(UserContentProvider.CONTENT_URI!!, values)
        return true
    }

    //Create, Update, and Delete Products
    fun addProduct(product: Product) {
        if (findProduct(product.productName.toString()) != null) {
            updateProduct(product)
        } else {
            val values = ContentValues()
            values.put(COLUMN_PRODUCTNAME, product.productName)
            values.put(COLUMN_DESCRIPTION, product.description)
            myCR.insert(MyContentProvider.CONTENT_URI!!, values)
        }
    }

    fun updateProduct(product: Product) {
        val selection = "productname =\"" + product.productName + "\""
        val values = ContentValues()
        values.put(COLUMN_PRODUCTNAME, product.productName)
        values.put(COLUMN_DESCRIPTION, product.description)
        myCR.update(MyContentProvider.CONTENT_URI!!, values, selection, null)
    }

    fun findProduct(productname: String): Product? {
        val projection = arrayOf(COLUMN_ID, COLUMN_PRODUCTNAME, COLUMN_DESCRIPTION)
        val selection = "productname =\"$productname\""
        val cursor = myCR.query(MyContentProvider.CONTENT_URI!!, projection, selection, null, null)
        var product: Product? = Product()
        if (cursor!!.moveToFirst()) {
            cursor.moveToFirst()
            product!!.iD = cursor.getString(0).toInt()
            product.productName = cursor.getString(1)
            product.description = cursor.getString(2)
            cursor.close()
        } else {
            product = null
        }
        return product
    }

    fun deleteProduct(productname: String): Boolean {
        var result = false
        val selection = "productname = \"$productname\""
        val rowsDeleted = myCR.delete(MyContentProvider.CONTENT_URI!!, selection, null)
        if (rowsDeleted > 0) result = true
        return result
    }

    fun selectAllProducts(): ArrayList<Product> {
        val productList = ArrayList<Product>()
        val projection = arrayOf(COLUMN_ID, COLUMN_PRODUCTNAME, COLUMN_DESCRIPTION)
        val selection = ""
        val cursor = myCR.query(MyContentProvider.CONTENT_URI!!, projection, null, null, null)
        while (cursor!!.moveToNext()) {
            productList.add(Product(cursor.getString(0).toInt(), cursor.getString(1), cursor.getString(1)))
        }
        cursor.close()
        return productList
    }

    //Create, Update, Search, and Delete Items
    fun addItem(item: Item) {
        if (findItem(item.code) != null) {
            updateItem(item)
        } else {
            val values = ContentValues()
            values.put(COLUMN_CODE, item.code)
            values.put(COLUMN_ITEMNAME, item.itemName)
            values.put(COLUMN_PRICE, item.price)
            myCR.insert(ItemContentProvider.CONTENT_URI!!, values)
        }
    }

    fun updateItem(item: Item) {
        val selection = "code =" + item.code
        val values = ContentValues()
        values.put(COLUMN_ITEMNAME, item.itemName)
        values.put(COLUMN_PRICE, item.price)
        myCR.update(ItemContentProvider.CONTENT_URI!!, values, selection, null)
    }

    fun findItem(itemcode: Int): Item? {
        val projection = arrayOf(COLUMN_CODE, COLUMN_ITEMNAME, COLUMN_PRICE)
        val selection = "code =$itemcode"
        val cursor = myCR.query(ItemContentProvider.CONTENT_URI!!, projection, selection, null, null)
        var item: Item? = Item()
        if (cursor!!.moveToFirst()) {
            cursor.moveToFirst()
            item!!.code = cursor.getString(0).toInt()
            item.itemName = cursor.getString(1)
            item.price = cursor.getString(2).toInt()
            cursor.close()
        } else {
            item = null
        }
        return item
    }

    fun deleteItem(itemCode: Int): Boolean {
        var result = false
        val selection = "code = \"$itemCode\""
        val rowsDeleted = myCR.delete(ItemContentProvider.CONTENT_URI!!, selection, null)
        if (rowsDeleted > 0) result = true
        return result
    }

    fun selectAllItems(): ArrayList<Item> {
        val itemlist = ArrayList<Item>()
        val projection = arrayOf(COLUMN_CODE, COLUMN_ITEMNAME, COLUMN_PRICE)
        val selection = ""
        val cursor = myCR.query(ItemContentProvider.CONTENT_URI!!, projection, null, null, null)
        while (cursor!!.moveToNext()) {
            itemlist.add(Item(cursor.getString(0).toInt(), cursor.getString(1), cursor.getString(2).toInt()))
        }
        cursor.close()
        return itemlist
    }

    fun selectItemsByItemName(itemName: String): ArrayList<Item> {
        val itemlist = ArrayList<Item>()
        val projection = arrayOf(COLUMN_CODE, COLUMN_ITEMNAME, COLUMN_PRICE)
        val selection = "itemname = \"$itemName\""
        val cursor = myCR.query(ItemContentProvider.CONTENT_URI!!, projection, null, null, null)
        while (cursor!!.moveToNext()) {
            itemlist.add(Item(cursor.getString(0).toInt(), cursor.getString(1), cursor.getString(2).toInt()))
        }
        cursor.close()
        return itemlist
    }

    companion object {
        private const val DATABASE_VERSION = 1
        private const val DATABASE_NAME = "productDB.db"
        const val TABLE_PRODUCTS = "products"
        const val TABLE_ITEMS = "items"
        const val TABLE_USER = "users"
        const val COLUMN_ID = "_id"
        const val COLUMN_PRODUCTNAME = "productname"
        const val COLUMN_DESCRIPTION = "description"
        const val COLUMN_CODE = "code"
        const val COLUMN_ITEMNAME = "itemname"
        const val COLUMN_PRICE = "price"
        const val COLUMN_USERNAME = "username"
        const val COLUMN_PASSWORD = "password"
    }
}