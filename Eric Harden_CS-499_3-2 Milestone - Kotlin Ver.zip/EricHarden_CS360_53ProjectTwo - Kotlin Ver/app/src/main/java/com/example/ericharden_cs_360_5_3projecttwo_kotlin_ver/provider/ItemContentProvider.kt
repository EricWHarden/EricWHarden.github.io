package com.example.ericharden_cs_360_5_3projecttwo_kotlin_ver.provider

import android.content.ContentProvider
import android.content.ContentValues
import android.content.UriMatcher
import android.database.Cursor
import android.database.sqlite.SQLiteQueryBuilder
import android.net.Uri
import android.text.TextUtils
import com.example.ericharden_cs_360_5_3projecttwo_kotlin_ver.MyDBHandler

//Establishes ItemContentProvider class using ContentProvider as a base
class ItemContentProvider : ContentProvider() {
    //Calls MyDBHandler class
    private var myDB: MyDBHandler? = null

    //Delete From Database functionality
    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<String>?): Int {
        val uriType = sURIMatcher.match(uri)
        val sqlDB = myDB!!.writableDatabase
        val rowsDeleted: Int = when (uriType) {
            ITEMS -> sqlDB.delete(MyDBHandler.TABLE_ITEMS, selection, selectionArgs)
            ITEMS_CODE -> {
                val id = uri.lastPathSegment
                if (TextUtils.isEmpty(selection)) {
                    sqlDB.delete(MyDBHandler.TABLE_ITEMS, MyDBHandler.COLUMN_CODE + "=" + id, null)
                } else {
                    sqlDB.delete(MyDBHandler.TABLE_ITEMS, MyDBHandler.COLUMN_CODE + "=" + id + " and " +
                            selection, selectionArgs)
                }
            }
            else -> throw IllegalArgumentException("Unknown URI: $uri")
        }
        context!!.contentResolver.notifyChange(uri, null)
        return rowsDeleted
    }

    //Currently throws exception for unimplemented functionality
    override fun getType(uri: Uri): String? {
        // TODO: Implement this to handle requests for the MIME type of the data
        // at the given URI.
        throw UnsupportedOperationException("Not yet implemented")
    }

    //Insert Record Into Database functionality
    override fun insert(uri: Uri, values: ContentValues?): Uri? {
        val uriType = sURIMatcher.match(uri)
        val sqlDB = myDB!!.writableDatabase
        val id: Long = when (uriType) {
            ITEMS -> sqlDB.insert(MyDBHandler.TABLE_ITEMS, null, values)
            else -> throw IllegalArgumentException("UNknown URI: $uri")
        }
        context!!.contentResolver.notifyChange(uri, null)
        return Uri.parse("$ITEMS_TABLE/$id")
    }

    //Return
    override fun onCreate(): Boolean {
        myDB = MyDBHandler(context, null, null, 1)
        return false
    }

    //Search for Item in Database functionality
    override fun query(uri: Uri, projection: Array<String>?, selection: String?,
                       selectionArgs: Array<String>?, sortOrder: String?): Cursor? {
        val queryBuilder = SQLiteQueryBuilder()
        queryBuilder.tables = MyDBHandler.TABLE_ITEMS
        val uriType = sURIMatcher.match(uri)
        when (uriType) {
            ITEMS_CODE -> queryBuilder.appendWhere(MyDBHandler.COLUMN_CODE + "="
                    + uri.lastPathSegment)
            ITEMS -> {}
            else -> throw IllegalArgumentException("Unknown URI")
        }
        val cursor = queryBuilder.query(myDB!!.readableDatabase, projection, selection, selectionArgs, null, null, sortOrder)
        cursor.setNotificationUri(context!!.contentResolver, uri)
        return cursor
    }

    //Update Item in Database functionality
    override fun update(uri: Uri, values: ContentValues?, selection: String?,
                        selectionArgs: Array<String>?): Int {
        val uriType = sURIMatcher.match(uri)
        val sqlDB = myDB!!.writableDatabase
        val rowsUpdated: Int = when (uriType) {
            ITEMS -> sqlDB.update(MyDBHandler.TABLE_ITEMS, values, selection, selectionArgs)
            ITEMS_CODE -> {
                val id = uri.lastPathSegment
                if (TextUtils.isEmpty(selection)) {
                    sqlDB.update(MyDBHandler.TABLE_ITEMS, values, MyDBHandler.COLUMN_CODE + "=" + id, null)
                } else {
                    sqlDB.update(MyDBHandler.TABLE_ITEMS, values, MyDBHandler.COLUMN_CODE + "=" + id + " and " +
                            selection, selectionArgs)
                }
            }
            else -> throw IllegalArgumentException("Unknown URI: $uri")
        }
        context!!.contentResolver.notifyChange(uri, null)
        return rowsUpdated
    }

    companion object {
        private const val AUTHORITY = "com.example.ericharden_cs_360_5_3projecttwo_kotlin_ver.provider.ItemContentProvider"
        private const val ITEMS_TABLE = "items"
        @JvmField
        val CONTENT_URI: Uri? = Uri.parse("content://$AUTHORITY/$ITEMS_TABLE")
        const val ITEMS = 2
        const val ITEMS_CODE = 3
        private val sURIMatcher = UriMatcher(UriMatcher.NO_MATCH)

        init {
            sURIMatcher.addURI(AUTHORITY, ITEMS_TABLE, ITEMS)
            sURIMatcher.addURI(AUTHORITY, "$ITEMS_TABLE/#", ITEMS_CODE)
        }
    }
}