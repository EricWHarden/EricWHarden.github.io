package com.example.ericharden_cs_360_5_3projecttwo_kotlin_ver

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class PromptActivity : AppCompatActivity() {
    private val RECIEVE_SMS_PERMISSION_CODE = 1
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_prompt)
        val grantPermission = findViewById<Button>(R.id.grant_permission_btn)
        grantPermission.setOnClickListener { view: View? -> seekPermission(view) }
        if (ContextCompat.checkSelfPermission(
                        this@PromptActivity, Manifest.permission.SEND_SMS) ==
                PackageManager.PERMISSION_GRANTED) {
            val intent = Intent(this@PromptActivity, DatabaseActivity::class.java)
            startActivity(intent)
        }
    }

    fun seekPermission(view: View?) {
        if (ContextCompat.checkSelfPermission(
                        this@PromptActivity, Manifest.permission.SEND_SMS) ==
                PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this@PromptActivity, "Permission already granted", Toast.LENGTH_SHORT).show()
            val intent = Intent(this@PromptActivity, DatabaseActivity::class.java)
            startActivity(intent)
        } else {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this@PromptActivity, Manifest.permission.SEND_SMS)) {
                AlertDialog.Builder(this)
                        .setTitle("Permmision required")
                        .setMessage("This permission is required so that you may recieve automated system notifications")
                        .setPositiveButton("GRANT") { dialog, which -> ActivityCompat.requestPermissions(this@PromptActivity, arrayOf(Manifest.permission.SEND_SMS), RECIEVE_SMS_PERMISSION_CODE) }
                        .setNegativeButton("DENY") { dialog, which -> dialog.dismiss() }
                        .create().show()
            } else {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.SEND_SMS), RECIEVE_SMS_PERMISSION_CODE)
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == RECIEVE_SMS_PERMISSION_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permission Granted", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Permission Denied", Toast.LENGTH_SHORT).show()
            }
        }
        val intent = Intent(this@PromptActivity, DatabaseActivity::class.java)
        startActivity(intent)
    }
}