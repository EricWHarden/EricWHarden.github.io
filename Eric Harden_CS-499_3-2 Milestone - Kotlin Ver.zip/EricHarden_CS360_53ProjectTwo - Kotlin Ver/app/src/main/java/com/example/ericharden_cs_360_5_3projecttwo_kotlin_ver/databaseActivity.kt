package com.example.ericharden_cs_360_5_3projecttwo_kotlin_ver

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.telephony.SmsManager
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

//Establishes databaseActivity class as an extension of AppCompatActivity
class DatabaseActivity : AppCompatActivity() {
    private var tl: TableLayout? = null
    private var itemCodeInput: EditText? = null
    private var itemNameInput: EditText? = null
    private var itemPriceInput: EditText? = null
    private var addCategory: Button? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_database)
        tl = findViewById(R.id.tableLayout)
        itemCodeInput = findViewById(R.id.product_name_input)
        itemNameInput = findViewById(R.id.product_description_input)
        itemPriceInput = findViewById(R.id.item_price_input)
        addCategory = findViewById(R.id.addCategory)
        addCategory?.setOnClickListener(View.OnClickListener {
            val intent = Intent(this@DatabaseActivity, ProductActivity::class.java)
            startActivity(intent)
        })
        populateTable()
    }

    //Add item to table
    fun addToTable(view: View?) {
        val eItemCode = itemCodeInput!!.text.toString()
        val eItemName = itemNameInput!!.text.toString()
        val eItemPrice = itemPriceInput!!.text.toString()
        if (eItemCode.isEmpty() || eItemName.isEmpty() || eItemPrice.isEmpty()) {
            Toast.makeText(this, "Please Fill in All the fields", Toast.LENGTH_SHORT).show()
            return
        }

        //Add to database
        val dbHandler = MyDBHandler(this, null, null, 1)
        val code = eItemCode.toInt()
        val price = eItemPrice.toInt()
        val item = Item(code, eItemName, price)
        dbHandler.addItem(item)
        //Clear input fields
        itemCodeInput!!.setText("")
        itemPriceInput!!.setText("")
        itemNameInput!!.setText("")
        populateTable()
    }

    //Populate grid view
    private fun populateTable() {
        val dbHandler = MyDBHandler(this, null, null, 1)
        val itemList = dbHandler.selectAllItems()
        val count = tl!!.childCount
        tl!!.removeViews(1, count - 1)
        for (item in itemList) {
            val tr = TableRow(this)
            tr.layoutParams = TableRow.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            tr.setBackgroundColor(Color.parseColor("#DAE8FC"))
            tr.setPadding(5, 5, 5, 5)
            val tx1 = TextView(this)
            val tx2 = TextView(this)
            val tx3 = TextView(this)
            tx1.text = item.code.toString()
            tx2.text = item.itemName
            tx3.text = item.price.toString()
            val img = ImageView(this)
            img.setImageResource(R.drawable.ic_action_delete)
            img.setOnClickListener { v -> if (removeItem(v)) deleteRow(v) }
            val img1 = ImageView(this)
            img1.setImageResource(R.drawable.ic_action_edit)
            img1.setOnClickListener { v -> lookUpItem(v) }
            tr.addView(tx1)
            tr.addView(tx2)
            tr.addView(tx3)
            tr.addView(img)
            tr.addView(img1)
            tl!!.addView(tr)
            item.itemName?.let { countItems(it) }
        }
    }

    //Delete row
    fun deleteRow(v: View) {
        val row = v.parent as View
        val container = row.parent as ViewGroup
        container.removeView(row)
        container.invalidate()
    }

    //Look up item to form
    private fun lookUpItem(view: View) {
        val dbHandler = MyDBHandler(this, null, null, 1)
        val row = view.parent as TableRow
        val textView = row.getChildAt(0) as TextView
        val item = dbHandler.findItem(textView.text.toString().toInt())
        if (item != null) {
            itemCodeInput!!.setText(item.code.toString())
            itemNameInput!!.setText(item.itemName)
            itemPriceInput!!.setText(item.price.toString())
        } else {
            itemCodeInput!!.setText(buildString {
            append("No Match Found")
        })
        }
    }

    //Remove item from table
    private fun removeItem(view: View): Boolean {
        val dbHandler = MyDBHandler(this, null, null, 1)
        val row = view.parent as TableRow
        val textView = row.getChildAt(0) as TextView
        val result = dbHandler.deleteItem(textView.text.toString().toInt())
        if (result) {
            itemCodeInput!!.setText(
                    buildString {
                        append("Record Deleted")
                    },
            )
            itemNameInput!!.setText("")
            itemPriceInput!!.setText("")
        } else itemCodeInput!!.setText(
                buildString {
                    append("Delete Unsuccessful")
                },
        )
        return result
    }

    //CountItems with the same name/category
    private fun countItems(productName: String): String {
        var count = 0
        val items = ArrayList<Item>()
        var itemsRunningLow = ""
        for (item in items) {
            count++
        }
        if (count < 10) {
            itemsRunningLow = productName
            sendSMS(productName)
        }
        return count.toString()
    }

    //Send SMS if item quantity is less than 10
    private fun sendSMS(item_name: String) {
        val phoneNum = "+3038274304" //txtPhoneNum.getText().toString();
        val message = item_name + "is running low."
        try {
            val smgr = SmsManager.getDefault()
            smgr.sendTextMessage(phoneNum, null, message, null, null)
            Toast.makeText(this@DatabaseActivity, "SMS Sent Successfully", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this@DatabaseActivity, "SMS Failed to Send, Please Try Again", Toast.LENGTH_SHORT).show()
        }
    }
}