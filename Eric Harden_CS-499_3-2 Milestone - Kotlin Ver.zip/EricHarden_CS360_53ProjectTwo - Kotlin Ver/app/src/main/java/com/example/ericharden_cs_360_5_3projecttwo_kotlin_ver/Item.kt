package com.example.ericharden_cs_360_5_3projecttwo_kotlin_ver

//Establishes Item class
class Item {
    //Getter and Setter Methods
    var code = 0
    var itemName: String? = null
    var price = 0

    constructor() {}

    //Constructor
    constructor(code: Int, itemname: String?, price: Int) {
        this.code = code
        itemName = itemname
        this.price = price
    }

    //Constructor taking two variables: itemname and price
    constructor(itemname: String?, price: Int) {
        itemName = itemname
        this.price = price
    }
}