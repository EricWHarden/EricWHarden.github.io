package com.example.ericharden_cs_360_5_3projecttwo_kotlin_ver.provider

import android.content.ContentProvider
import android.content.ContentValues
import android.content.UriMatcher
import android.database.Cursor
import android.database.sqlite.SQLiteQueryBuilder
import android.net.Uri
import android.text.TextUtils
import com.example.ericharden_cs_360_5_3projecttwo_kotlin_ver.MyDBHandler

//Establishes UserContentProvider class using ContentProvider as a base
class UserContentProvider : ContentProvider() {
    //Calls MyDBHandler class
    private var myDB: MyDBHandler? = null

    //Delete from User Table functionality
    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<String>?): Int {
        val uriType = sURIMatcher.match(uri)
        val sqlDB = myDB!!.writableDatabase
        val rowsDeleted: Int = when (uriType) {
            USER -> sqlDB.delete(MyDBHandler.TABLE_USER, selection, selectionArgs)
            USERNAME -> {
                val id = uri.lastPathSegment
                if (TextUtils.isEmpty(selection)) {
                    sqlDB.delete(MyDBHandler.TABLE_USER, MyDBHandler.COLUMN_USERNAME + "=" + id, null)
                } else {
                    sqlDB.delete(MyDBHandler.TABLE_USER, MyDBHandler.COLUMN_USERNAME + "=" + id + " and " +
                            selection, selectionArgs)
                }
            }
            else -> throw IllegalArgumentException("Unknown URI: $uri")
        }
        context!!.contentResolver.notifyChange(uri, null)
        return rowsDeleted
    }

    //Exception thrown for unfinished functionality
    override fun getType(uri: Uri): String? {
        throw UnsupportedOperationException("Not yet implemented")
    }

    //Insert into User Table functionality
    override fun insert(uri: Uri, values: ContentValues?): Uri? {
        val uriType = sURIMatcher.match(uri)
        val sqlDB = myDB!!.writableDatabase
        val id: Long = when (uriType) {
            USER -> sqlDB.insert(MyDBHandler.TABLE_USER, null, values)
            else -> throw IllegalArgumentException("Unknown URI: $uri")
        }
        context!!.contentResolver.notifyChange(uri, null)
        return Uri.parse("$USER_TABLE/$id")
    }

    //Return
    override fun onCreate(): Boolean {
        myDB = MyDBHandler(context, null, null, 1)
        return false
    }

    //Search User Table functionality
    override fun query(uri: Uri, projection: Array<String>?, selection: String?,
                       selectionArgs: Array<String>?, sortOrder: String?): Cursor? {
        val queryBuilder = SQLiteQueryBuilder()
        queryBuilder.tables = MyDBHandler.TABLE_USER
        val uriType = sURIMatcher.match(uri)
        when (uriType) {
            USERNAME -> queryBuilder.appendWhere(MyDBHandler.COLUMN_ID + "="
                    + uri.lastPathSegment)
            USER -> {}
            else -> throw IllegalArgumentException("Unknown URI")
        }
        val cursor = queryBuilder.query(myDB!!.readableDatabase, projection, selection, selectionArgs, null, null, sortOrder)
        cursor.setNotificationUri(context!!.contentResolver, uri)
        return cursor
    }

    //Update User Table functionality
    override fun update(uri: Uri, values: ContentValues?, selection: String?,
                        selectionArgs: Array<String>?): Int {
        val uriType = sURIMatcher.match(uri)
        val sqlDB = myDB!!.writableDatabase
        val rowsUpdated: Int = when (uriType) {
            USER -> sqlDB.update(MyDBHandler.TABLE_USER, values, selection, selectionArgs)
            USERNAME -> {
                val id = uri.lastPathSegment
                if (TextUtils.isEmpty(selection)) {
                    sqlDB.update(MyDBHandler.TABLE_USER, values, MyDBHandler.COLUMN_USERNAME + "=" + id, null)
                } else {
                    sqlDB.update(MyDBHandler.TABLE_USER, values, MyDBHandler.COLUMN_USERNAME + "=" + id + " and " +
                            selection, selectionArgs)
                }
            }
            else -> throw IllegalArgumentException("Unknown URI: $uri")
        }
        context!!.contentResolver.notifyChange(uri, null)
        return rowsUpdated
    }

    companion object {
        private const val AUTHORITY = "com.example.ericharden_cs_360_5_3projecttwo_kotlin_ver.provider.UserContentProvider"
        private const val USER_TABLE = "users"
        @JvmField
        val CONTENT_URI: Uri? = Uri.parse("content://$AUTHORITY/$USER_TABLE")
        const val USER = 4
        const val USERNAME = 5
        private val sURIMatcher = UriMatcher(UriMatcher.NO_MATCH)

        init {
            sURIMatcher.addURI(AUTHORITY, USER_TABLE, USER)
            sURIMatcher.addURI(AUTHORITY, "$USER_TABLE/#", USERNAME)
        }
    }
}