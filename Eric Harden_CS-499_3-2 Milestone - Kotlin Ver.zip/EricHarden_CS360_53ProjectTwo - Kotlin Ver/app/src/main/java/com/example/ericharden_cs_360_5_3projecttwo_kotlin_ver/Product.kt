package com.example.ericharden_cs_360_5_3projecttwo_kotlin_ver

class Product {

    //Getter and Setter Methods
    var iD = 0
    var productName: String? = null
    var description: String? = null

    constructor() {}
    constructor(id: Int, productname: String?, description: String?) {
        iD = id
        productName = productname
        this.description = description
    }

    constructor(productname: String?, description: String?) {
        productName = productname
        this.description = description
    }
}