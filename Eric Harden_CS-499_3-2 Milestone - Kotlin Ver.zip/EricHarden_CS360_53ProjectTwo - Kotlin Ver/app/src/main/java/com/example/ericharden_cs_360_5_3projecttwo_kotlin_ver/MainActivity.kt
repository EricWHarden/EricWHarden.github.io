package com.example.ericharden_cs_360_5_3projecttwo_kotlin_ver

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

//Establishes MainActivity class as extension of AppCompatActivity
class MainActivity : AppCompatActivity() {
    var loginBtn: Button? = null
    var signupBtn: Button? = null
    var username: EditText? = null
    var password: EditText? = null
    var forgotPassword: TextView? = null
    var userState: TextView? = null

    //Functionality for login text fields and button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        username = findViewById(R.id.username_input)
        password = findViewById(R.id.password_input)
        loginBtn = findViewById(R.id.login_btn)
        loginBtn?.setOnClickListener { v ->

            //Validate credentials on hitting login button
            if (validateInput(v)) {
                signIn(v)
            }
        }
        //Functionality for sign up button
        signupBtn = findViewById(R.id.signup_btn)
        signupBtn?.setOnClickListener { v ->
            if (validateInput(v)) {
                register(v)
            }
        }
        //Functionality for forgot password link
        forgotPassword = findViewById(R.id.forgot_password_link)
        forgotPassword?.setOnClickListener { Toast.makeText(this@MainActivity, "This feature will be implemented in a future release.", Toast.LENGTH_SHORT).show() }
        userState = findViewById(R.id.user_state)
    }

    //Sign In
    fun signIn(view: View?) {
        val usernameIn = username!!.text.toString()
        val passwordIn = password!!.text.toString()
        val db = MyDBHandler(this, null, null, 1)
        val user = db.findUser(usernameIn, passwordIn)
        if (user != null) {
            val intent = Intent(this@MainActivity, PromptActivity::class.java)
            startActivity(intent)
        } else {
            userState!!.text = buildString {
            append("User Not Found, Create Account to Login")
            }
        }
        username!!.setText("")
        password!!.setText("")
    }

    //Create An Account
    fun register(view: View?) {
        val usernameIn = username!!.text.toString()
        val passwordIn = password!!.text.toString()
        val db = MyDBHandler(this, null, null, 1)
        val user = User(usernameIn, passwordIn)
        db.addUser(user)
        if (db.addUser(user)) {
            userState!!.text = buildString {
            append("Your account has been created, please login to continue.")
            }
        } else {
            userState!!.text = buildString {
            append("Registration error, please try again.")
            }
        }
        username!!.setText("")
        password!!.setText("")
    }

    //Validate Input
    fun validateInput(v: View?): Boolean {
        if (username!!.text.toString().isEmpty() || password!!.text.toString().isEmpty()) {
            Toast.makeText(this, "Please Fill In All Fields", Toast.LENGTH_SHORT).show()
            return false
        }
        return true
    }
}