package com.example.ericharden_cs_360_5_3projecttwo_kotlin_ver

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.telephony.SmsManager
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class ProductActivity : AppCompatActivity() {
    private var tl: TableLayout? = null
    private var productName: EditText? = null
    private var productDescription: EditText? = null
    private var addItem: Button? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_product)
        productName = findViewById(R.id.product_name_input)
        productDescription = findViewById(R.id.product_description_input)
        tl = findViewById(R.id.tableLayout)
        addItem = findViewById(R.id.addItem)
        addItem?.setOnClickListener {
            val intent = Intent(this@ProductActivity, DatabaseActivity::class.java)
            startActivity(intent)
        }
        populateTable()
    }

    //Add New Product
    fun newProduct(view: View?) {
        val eProductName = productName!!.text.toString()
        val eProductDesc = productDescription!!.text.toString()
        if (eProductName.isEmpty() || eProductDesc.isEmpty()) {
            Toast.makeText(this, "Please Fill in All the fields", Toast.LENGTH_SHORT).show()
            return
        }
        /*Add to databatabase**/
        val dbHandler = MyDBHandler(this, null, null, 1)
        val product = Product(eProductName, eProductDesc)
        dbHandler.addProduct(product)
        /**/productName!!.setText("")
        productDescription!!.setText("")
        populateTable()
    }

    //Lookup Product
    fun lookUpProduct(view: View) {
        val dbHandler = MyDBHandler(this, null, null, 1)
        val row = view.parent as TableRow
        val textView = row.getChildAt(1) as TextView
        val product = dbHandler.findProduct(textView.text.toString())
        if (product != null) {
            productName!!.setText(product.productName)
            productDescription!!.setText(product.description)
        } else {
            productName!!.setText("No Match Found")
        }
    }

    //Delete Product
    fun removeProduct(view: View): Boolean {
        val dbHandler = MyDBHandler(this, null, null, 1)
        val row = view.parent as TableRow
        val textView = row.getChildAt(1) as TextView
        val result = dbHandler.deleteProduct(textView.text.toString())
        if (result) {
            productName!!.setText("Record Deleted")
            productDescription!!.setText("")
        } else productName!!.setText("No Match Found")
        return result
    }

    //Delete Row
    fun deleteRow(v: View) {
        val row = v.parent as View
        val container = row.parent as ViewGroup
        container.removeView(row)
        container.invalidate()
    }

    //Populate Table
    fun populateTable() {
        val dbHandler = MyDBHandler(this, null, null, 1)
        val productList = dbHandler.selectAllProducts()
        val count = tl!!.childCount
        tl!!.removeViews(1, count - 1)
        for (product in productList) {
            val tr = TableRow(this)
            tr.layoutParams = TableRow.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            tr.setBackgroundColor(Color.parseColor("#DAE8FC"))
            tr.setPadding(5, 5, 5, 5)
            val tx1 = TextView(this)
            val tx2 = TextView(this)
            val tx3 = TextView(this)
            tx1.text = product.iD.toString()
            tx2.text = product.productName
            tx3.text = countItems(product.productName)
            val img = ImageView(this)
            img.setImageResource(R.drawable.ic_action_delete)
            img.setOnClickListener { v -> if (removeProduct(v)) deleteRow(v) }
            val img1 = ImageView(this)
            img1.setImageResource(R.drawable.ic_action_edit)
            img1.setOnClickListener { view: View -> lookUpProduct(view) }
            tr.addView(tx1)
            tr.addView(tx2)
            tr.addView(tx3)
            tr.addView(img)
            tr.addView(img1)
            tl!!.addView(tr)
        }
    }

    //Count Items With the Same Product Name
    fun countItems(productName: String?): String {
        var count = 0
        val items = ArrayList<Item>()
        for (item in items) {
            count++
        }
        sendSMS(productName)
        return count.toString()
    }

    //Send SMS
    fun sendSMS(item_name: String?) {
        val phoneNo = "" //txtphoneNo.getText().toString();
        val message = "$item_name is running low."
        try {
            val smgr = SmsManager.getDefault()
            smgr.sendTextMessage(phoneNo, null, message, null, null)
            Toast.makeText(this@ProductActivity, "SMS Sent Successfully", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this@ProductActivity, "SMS Failed to Send, Please try again", Toast.LENGTH_SHORT).show()
        }
    }
}